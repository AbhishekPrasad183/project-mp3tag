#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "view.h"
#define RESET       "\033[0m"
#define RED         "\033[31m"
#define GREEN       "\033[32m"
#define YELLOW      "\033[33m"
#define BLUE        "\033[34m"
#define CYAN        "\033[36m"
#define BOLDWHITE   "\033[1m\033[37m"

OperationType check_operation (char* argv[])
{
   if(strncmp(argv[1],"-v",2)== 0)
   {
     return p_view; 
   }
   else if(strncmp(argv[1],"-e",2)== 0)
   {
    return p_edit;
   }
   else if(strncmp(argv[1],"--help",6)== 0)
   {
    return p_help;
   }
   else
   {
    return  p_unsupported;
   }

}

Status read_and_validate_mp3_file(char*argv[],TagInfo* mp3tagInfo)
{
  if(argv[2] ==NULL)
  {
    printf(YELLOW"INFO: for viewing tag -v <file_name.mp3>\n"RESET);//checking the view tag <filename.mp3>
    return p_failure;
  }
  else
  {
    mp3tagInfo->fptr_mp3 = fopen(argv[2],"r+");//opening for reading the file
    if(mp3tagInfo->fptr_mp3 != NULL)//
    {
      char  str[3];
      fread(str,1,3,mp3tagInfo->fptr_mp3);//once check this 
      
      if(str,"ID3",3)//passing arguments
      {  
        printf("\n------------------------------Version V2.3--------------------------------\n");//For version V2.3
        //printf("-----------------------\n");
      }
      else
      {
        printf(RED"ERROR:The file signature is not matching!"RESET);//Checking error message analyzing it
        printf(RED"PLEASE ENTER VALID ARGUMENTS!"RESET);//valid arguments failure
        return p_failure;
      }
    }
    else
    {
      printf(RED"ERROR :Unable to open the file!.\n"RESET);
      printf(RED"PLEASE ENTER VALID ARGUMENTS!"RESET);
      return p_failure;
    }

    fclose(mp3tagInfo->fptr_mp3);
  
  }
  //No failure returned so return p_success
  return p_success;
}  

//can we use memcpy

Status view_tag (char* argv[], TagInfo* mp3tagInfo)
{
    mp3tagInfo->fptr_mp3=fopen(argv[2],"r+");
    fseek(mp3tagInfo->fptr_mp3,10L,SEEK_SET);

    Status RET;
    //About to the display the Information about the Title tag
    RET=get_and_display_data(GREEN"Title\t\t\t\t:\t\t"RESET,"TIT2",mp3tagInfo->frame_Id,&mp3tagInfo->title_tag_size,mp3tagInfo->title_tag,mp3tagInfo->fptr_mp3);
    if(RET == p_failure)
    {
      printf(RED"ERROR: Title Frame ID Contents cannot be displayed.\n"RESET);
      return p_failure;
    }

    RET=get_and_display_data("artist\t\t\t\t:\t\t","TPE1",mp3tagInfo->frame_Id,&mp3tagInfo->artist_tag_size,mp3tagInfo->artist_tag,mp3tagInfo->fptr_mp3);
    if(RET == p_failure)
    {
      printf(RED"ERROR: Artist Frame ID Contents cannot be displayed.\n"RESET);
      return p_failure;
    }

    RET=get_and_display_data(GREEN"ALBUM\t\t\t\t:\t\t"RESET,"TALB",mp3tagInfo->frame_Id,&mp3tagInfo->album_tag_size,mp3tagInfo->album_tag,mp3tagInfo->fptr_mp3);
    if(RET == p_failure)
    {
      printf(RED"ERROR: Album Frame ID cannot be displayed.\n"RESET);
      return p_failure;
    }

    RET=get_and_display_data("YEAR\t\t\t\t:\t\t","TYER",mp3tagInfo->frame_Id,&mp3tagInfo->year_size,mp3tagInfo->year,mp3tagInfo->fptr_mp3);
    if(RET ==p_failure)
    {
      printf(RED"ERROR: Year Frame ID cannot be displayed.\n"RESET);
      return p_failure;
    }
    RET=get_and_display_data(GREEN"MUSIC\t\t\t\t:\t\t"RESET,"TCON",mp3tagInfo->frame_Id,&mp3tagInfo->content_type_size,mp3tagInfo->content_type,mp3tagInfo->fptr_mp3);
    if(RET == p_failure)
    {
      printf("ERROR: Content Type Frame ID cannot be displayed.\n");
      return p_failure;
    }
    RET=get_and_display_data(GREEN"Language\t\t\t:\t\t"RESET,"COMM",mp3tagInfo->frame_Id,&mp3tagInfo->comment_size,mp3tagInfo->comments,mp3tagInfo->fptr_mp3);
    if(RET ==p_failure)
    {
      printf(RED"Error: Content Type Frame ID Content cannot be displayed.\n"RESET);
      return p_failure;
    }

    printf("----------------------------------------------------\n");
    fclose(mp3tagInfo->fptr_mp3);

    return p_success;
}  

//To view the contents of particular frame ID
/* Input: Frame ID, Frame ID Tag (desired), Frame ID tag (to be extracted from '.mp3' file, Frame ID size, Frame ID contents and File pointer
 * Output: Frame ID contents are displayed
 * Return Value: p_success or p_failure*/

Status get_and_display_data(const char* str_frame,const char*str_Id,char*frame_Id,uint*tag_size,char*tag,FILE*fptr)
{
  int count;
  printf("MP3 position = %ld.\n",ftell(fptr));
  count=fread(frame_Id,1,4,fptr);//reading the four characters from the FRAME ID tag present
  if(count<4)//error handling
  {
    printf(RED"Error: Unable to read the MP3 File.\n"RESET);
    return p_failure;

  }
  else //Reversal of the bytes after reading to get the correct value of tag_size XOR reversal method
  {
     if((strncmp(frame_Id,str_Id,4))== 0)
    {
      count =fread(tag_size,4,1,fptr);
       /*fread() stores the size in the reverse order of what is present in the Hex dump of the MP3 file.
              Eg.- Hex dump: 00 00 00 2f (MSB to LSB).
                   fread() stores the value in 'tag_size' as: 00 00 00 2f (LSB to MSB)
              So, the Bytes shall be reversed after storing in 'tag_size' to get the Correct value.*/
      
      if(count < 1)
      {
      printf(RED"Error: Unable to read from the MP3 file.\n"RESET);
      return p_failure;
      }

      else
      {

        char*pos =(char*)tag_size;
    
    
        for(int i=0;i<((sizeof(uint))/2);i++)
        { 
          pos[i]=pos[i]^pos[(sizeof (uint))-i - 1];
          pos [(sizeof (uint)) - i - 1] = pos [i] ^ pos [(sizeof (uint)) - i - 1];
          pos[i]=pos[i]^pos[(sizeof (uint))-i - 1];
        } 
        printf("%sSize=%u.\n",str_frame,*tag_size);
        tag=(char*)malloc (((*tag_size)*sizeof(char)));
        fseek(fptr,3L,SEEK_CUR);//1 BYTE OF flag is included in the size and 2 bytes of flag is skipped,Total of 3 bytes of flag is skipped.
        count=fread(tag,1,(*tag_size-1),fptr);

        if(count<(*tag_size -1))
        {
          printf(RED"Error: Unable to read from the MP3 file.\n"RESET);
          return p_failure;
        }
        else
        {
          tag[*tag_size -1]='\0';
          printf("%-10s%s.\n",str_frame,tag);

        }

      }

    }
    
    else
    {
      printf (RED"ERROR: %s Frame ID not found.\n"RESET, str_Id);
      return p_failure;
    }

  }

free(tag);
tag=NULL;

return p_success;

}